import psutil
# Simulate high usage to test alert
cpu = 40   # Instead of psutil.cpu_percent()
memory = 50
disk = 70

def get_current_metrics():
    return {
        "cpu": psutil.cpu_percent(interval=1),
        "memory": psutil.virtual_memory().percent,
        "disk": psutil.disk_usage('/').percent
    }
is_alert = check_alerts(cpu, memory, disk)

if cpu > 80 or memory > 50 or disk > 80:
    play_alert()

