import tkinter as tk
from tkinter import ttk, messagebox
import ttkbootstrap as tb
from ttkbootstrap.constants import *
import psutil
import platform
import socket
from datetime import datetime, timedelta
import shutil
import matplotlib.pyplot as plt
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg
import pygame
import threading
from db import save_metrics  # Your custom DB save function

# Initialize Pygame Mixer for sound alerts
pygame.mixer.init()

def play_alert():
    def run_sound():
        try:
            pygame.mixer.music.load("alert.mp3")  # Make sure alert.mp3 is in the same folder
            pygame.mixer.music.play()
        except Exception as e:
            print(f"Could not play sound: {e}")
    threading.Thread(target=run_sound, daemon=True).start()

def get_system_info():
    uname = platform.uname()
    ip_address = socket.gethostbyname(socket.gethostname())
    return uname.system, uname.node, uname.release, uname.version, ip_address

class RemoteMonitorApp:
    def __init__(self, root):
        self.root = root
        self.root.title("Advanced Remote Server Monitoring System")
        self.root.attributes('-fullscreen', True)
        self.root.configure(bg='#2C3E50')

        # Bind Escape to exit fullscreen / close app
        self.root.bind("<Escape>", lambda e: self.root.destroy())

        self.cpu_usage_list = []
        self.timestamps = []
        self.start_time = datetime.now()

        self.create_widgets()
        self.update_data()

    def create_widgets(self):
        # ttkbootstrap style
        style = ttk.Style()
        style.configure('TLabel', font=('Helvetica', 14), background='#2C3E50', foreground='white')

        # Get static system info
        system, node, release, version, ip = get_system_info()

        # System Info Labels
        info_rows = [
            ('Hostname', node),
            ('IP Address', ip),
            ('OS', f"{system} {release}"),
        ]
        for i, (label, value) in enumerate(info_rows):
            ttk.Label(self.root, text=f"{label}:", style='TLabel').grid(row=i, column=0, sticky='w', padx=10, pady=3)
            ttk.Label(self.root, text=value, style='TLabel').grid(row=i, column=1, sticky='w', padx=10, pady=3)

        # Dynamic Metric Labels - placeholders for update
        metric_labels = [
            'CPU Usage', 'CPU Cores', 'CPU Frequency', 'Memory Usage', 'Swap Usage',
            'Disk Usage', 'Free Disk', 'Battery', 'Network Sent', 'Network Received', 'Uptime'
        ]

        self.labels = {}
        start_row = len(info_rows)
        for i, label in enumerate(metric_labels, start=start_row):
            ttk.Label(self.root, text=f"{label}:", style='TLabel').grid(row=i, column=0, sticky='w', padx=10, pady=3)
            self.labels[label] = ttk.Label(self.root, text="", style='TLabel')
            self.labels[label].grid(row=i, column=1, sticky='w', padx=10, pady=3)

        # Alert label (red text)
        self.alert_label = ttk.Label(self.root, text='', foreground='red', background='#2C3E50',
                                     font=('Helvetica', 16, 'bold'))
        self.alert_label.grid(row=0, column=2, padx=20, pady=3, sticky='n')

        # Demo alert button
        demo_row = start_row + len(metric_labels) + 1
        self.demo_alert_button = ttk.Button(self.root, text="Trigger Demo Alert", command=self.show_demo_alert)
        self.demo_alert_button.grid(row=demo_row, column=1, padx=10, pady=10, sticky='ew')

        # Exit button
        self.exit_button = ttk.Button(self.root, text="Exit", command=self.root.destroy)
        self.exit_button.grid(row=demo_row, column=0, padx=10, pady=10, sticky='ew')

        # CPU Usage Graph
        self.figure, self.ax = plt.subplots(figsize=(7, 3))
        self.canvas = FigureCanvasTkAgg(self.figure, self.root)
        self.canvas.get_tk_widget().grid(row=demo_row + 1, column=0, columnspan=3, padx=20, pady=10)

    def update_data(self):
        try:
            # Gather system metrics
            cpu_percent = psutil.cpu_percent()
            cpu_cores = psutil.cpu_count(logical=True)
            cpu_freq = psutil.cpu_freq()
            mem = psutil.virtual_memory()
            swap = psutil.swap_memory()
            disk = psutil.disk_usage('/')
            total, used, free = shutil.disk_usage('/')
            battery = psutil.sensors_battery()
            net = psutil.net_io_counters()
            uptime = datetime.now() - self.start_time

            # Update labels
            self.labels['CPU Usage'].config(text=f"{cpu_percent}%")
            self.labels['CPU Cores'].config(text=cpu_cores)
            self.labels['CPU Frequency'].config(text=f"{cpu_freq.current:.2f} MHz" if cpu_freq else "N/A")
            self.labels['Memory Usage'].config(text=f"{mem.percent}%")
            self.labels['Swap Usage'].config(text=f"{swap.percent}%")
            self.labels['Disk Usage'].config(text=f"{disk.percent}%")
            self.labels['Free Disk'].config(text=f"{free // (2**30)} GB")
            battery_text = "N/A"
            if battery:
                battery_text = f"{battery.percent}% {'(Plugged)' if battery.power_plugged else '(Unplugged)'}"
            self.labels['Battery'].config(text=battery_text)
            self.labels['Network Sent'].config(text=f"{net.bytes_sent // (1024**2)} MB")
            self.labels['Network Received'].config(text=f"{net.bytes_recv // (1024**2)} MB")
            self.labels['Uptime'].config(text=str(timedelta(seconds=int(uptime.total_seconds()))))

            # Save to DB
            save_metrics(cpu_percent, mem.percent, disk.percent)

            # Alert check
            if cpu_percent > 85 or mem.percent > 85 or disk.percent > 90:
                self.alert_label.config(text="⚠️ Alert: High Resource Usage!")
                play_alert()
            else:
                self.alert_label.config(text='')

            # Update CPU usage graph
            current_time = datetime.now().strftime('%H:%M:%S')
            self.cpu_usage_list.append(cpu_percent)
            self.timestamps.append(current_time)
            if len(self.cpu_usage_list) > 20:
                self.cpu_usage_list.pop(0)
                self.timestamps.pop(0)

            self.ax.clear()
            self.ax.plot(self.timestamps, self.cpu_usage_list, marker='o', linestyle='-')
            self.ax.set_title('CPU Usage Over Time')
            self.ax.set_ylabel('CPU (%)')
            self.ax.set_xticks(range(len(self.timestamps)))
            self.ax.set_xticklabels(self.timestamps, rotation=45, fontsize=8)
            self.figure.tight_layout()
            self.canvas.draw()

        except Exception as e:
            print(f"Error updating data: {e}")

        # Schedule next update every 3 seconds
        self.root.after(3000, self.update_data)

    def show_demo_alert(self):
        play_alert()
        messagebox.showwarning("Demo Alert", "This is a demo alert triggered by the alert button!")

if __name__ == '__main__':
    root = tb.Window(themename="superhero")  # Use ttkbootstrap window for modern UI
    app = RemoteMonitorApp(root)
    root.mainloop()
