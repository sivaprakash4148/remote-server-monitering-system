import tkinter as tk
from tkinter import ttk
import pygame
import threading
import tkinter as tk
import psutil
import time

def update_metrics():
    cpu = psutil.cpu_percent()
    memory = psutil.virtual_memory().percent
    disk = psutil.disk_usage('/').percent

    cpu_label.config(text=f"CPU Usage: {cpu}%")
    memory_label.config(text=f"Memory Usage: {memory}%")
    disk_label.config(text=f"Disk Usage: {disk}%")

    # Update every 2 seconds
    window.after(2000, update_metrics)

# GUI Setup
window = tk.Tk()
window.title("Server Monitor")
window.geometry("300x200")
window.resizable(False, False)

cpu_label = tk.Label(window, text="CPU Usage: ", font=("Arial", 14))
cpu_label.pack(pady=10)

memory_label = tk.Label(window, text="Memory Usage: ", font=("Arial", 14))
memory_label.pack(pady=10)

disk_label = tk.Label(window, text="Disk Usage: ", font=("Arial", 14))
disk_label.pack(pady=10)

update_metrics()
window.mainloop()

self.alert_label = ttk.Label(self.frame, text="", font=("Helvetica", 14), foreground="red")
self.alert_label.pack(pady=10)

demo_button = ttk.Button(self.frame, text="🔊 Play Demo Alert", command=play_alert)
demo_button.pack(pady=10)
