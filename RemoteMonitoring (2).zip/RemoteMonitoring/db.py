import mysql.connector

def get_connection():
    return mysql.connector.connect(
        host="localhost",
        user="root",
        password="Siva4148$",   
        database="monitoring_system"
    )

def save_metrics(cpu, memory, disk):
    conn = get_connection()
    cursor = conn.cursor()
    cursor.execute("INSERT INTO metrics (server_id, cpu_usage, memory_usage, disk_usage, timestamp) VALUES (1, %s, %s, %s, NOW())", (cpu, memory, disk))
    conn.commit()
    conn.close()
