import psutil
import mysql.connector
import datetime

# Connect to MySQL
db = mysql.connector.connect(
    host="localhost",
    user="root",          # or root
    password="Siva4148$",   # use your actual password
    database="monitoring_system"
)
cursor = db.cursor()

# Get system metrics
cpu = psutil.cpu_percent()
memory = psutil.virtual_memory().percent
disk = psutil.disk_usage('/').percent
timestamp = datetime.datetime.now()

server_id = 1  # Make sure this server ID exists in 'servers' table

# Save to database
query = "INSERT INTO metrics (server_id, cpu_usage, memory_usage, disk_usage, timestamp) VALUES (%s, %s, %s, %s, %s)"
cursor.execute(query, (server_id, cpu, memory, disk, timestamp))
db.commit()

# Display everything
print("===== Server Metrics Saved =====")
print(f"Timestamp     : {timestamp.strftime('%Y-%m-%d %H:%M:%S')}")
print(f"Server ID     : {server_id}")
print(f"CPU Usage     : {cpu}%")
print(f"Memory Usage  : {memory}%")
print(f"Disk Usage    : {disk}%")
print("================================")

cursor.close()
db.close()

