import tkinter as tk
from tkinter import ttk
import ttkbootstrap as tb
from ttkbootstrap.constants import *
import psutil
import platform
import socket
from datetime import datetime
import matplotlib.pyplot as plt
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg
from db import save_metrics

def get_system_info():
    uname = platform.uname()
    ip_address = socket.gethostbyname(socket.gethostname())
    return uname.system, uname.node, uname.release, uname.version, ip_address

def update_data():
    cpu = psutil.cpu_percent()
    mem = psutil.virtual_memory().percent
    disk = psutil.disk_usage('/').percent
    uptime = datetime.now() - start_time

    cpu_var.set(f"{cpu}%")
    mem_var.set(f"{mem}%")
    disk_var.set(f"{disk}%")
    uptime_var.set(str(uptime).split('.')[0])

    save_metrics(cpu, mem, disk)

    # Update plot
    timestamps.append(datetime.now().strftime("%H:%M:%S"))
    cpu_values.append(cpu)
    if len(cpu_values) > 20:
        cpu_values.pop(0)
        timestamps.pop(0)
    ax.clear()
    ax.plot(timestamps, cpu_values, marker='o')
    ax.set_title("CPU Usage Over Time")
    ax.set_ylabel("CPU (%)")
    ax.set_xticklabels(timestamps, rotation=45)

    canvas.draw()
    root.after(2000, update_data)

# UI Setup
root = tb.Window(themename="superhero")
root.title("Advanced Server Monitoring Dashboard")
root.attributes('-fullscreen', True)  # Fullscreen

frame = ttk.Frame(root, padding=10)
frame.pack(fill=BOTH, expand=True)

# System Info
system, node, release, version, ip = get_system_info()
ttk.Label(frame, text=f"Hostname: {node}", font=('Arial', 14)).grid(row=0, column=0, sticky=W)
ttk.Label(frame, text=f"IP Address: {ip}", font=('Arial', 14)).grid(row=0, column=1, sticky=W)
ttk.Label(frame, text=f"OS: {system} {release}", font=('Arial', 14)).grid(row=0, column=2, sticky=W)

# Metrics
cpu_var = tk.StringVar()
mem_var = tk.StringVar()
disk_var = tk.StringVar()
uptime_var = tk.StringVar()

style = {"font": ('Arial', 20), "padding": 10}
ttk.Label(frame, text="CPU Usage:", **style).grid(row=1, column=0)
ttk.Label(frame, textvariable=cpu_var, **style).grid(row=1, column=1)
ttk.Label(frame, text="Memory Usage:", **style).grid(row=2, column=0)
ttk.Label(frame, textvariable=mem_var, **style).grid(row=2, column=1)
ttk.Label(frame, text="Disk Usage:", **style).grid(row=3, column=0)
ttk.Label(frame, textvariable=disk_var, **style).grid(row=3, column=1)
ttk.Label(frame, text="Uptime:", **style).grid(row=4, column=0)
ttk.Label(frame, textvariable=uptime_var, **style).grid(row=4, column=1)

# Plot Section
fig, ax = plt.subplots(figsize=(7, 3))
canvas = FigureCanvasTkAgg(fig, master=frame)
canvas.get_tk_widget().grid(row=5, column=0, columnspan=3)

# Exit Button
ttk.Button(frame, text="Exit", command=root.destroy).grid(row=6, column=2, sticky=E, padx=20, pady=10)

# Start Data Update
start_time = datetime.now()
timestamps = []
cpu_values = []
update_data()
root.mainloop()
